# Contributing

Thanks for helping improve AI Agent Security Center.

## Before opening an issue or pull request

- Do not publish real credentials, private scan reports, customer data, or private Skill files. Use the synthetic fixtures in `tests/fixtures/` when reporting a security issue.
- For a suspected vulnerability, follow [SECURITY.md](SECURITY.md) and report it privately instead of opening a public issue.
- Describe the platform, steps to reproduce, expected behavior, and actual behavior.

## Development checks

Backend development uses Python 3.11 or newer. Install the dependencies and run tests from the repository root:

```bash
python -m pip install -r backend/requirements-dev.txt
python -m pytest -q
```

The Vue interface can be checked with Node.js 20.19 or newer:

```bash
cd frontend
npm ci
npm run build
```

Building desktop installers additionally requires Rust stable and the platform prerequisites listed in [README.md](README.md#從源碼構建桌面安裝包). A sidecar must be built on the target operating system and architecture.

## Pull requests

Keep changes focused, add or update tests for behavior changes, and update the README when user-visible behavior or platform requirements change. Never add code that executes files from an audited repository or transmits their contents without a clearly described, explicit opt-in.
