# Third-Party Notices

The MIT license in [`LICENSE`](LICENSE) applies to original project code and documentation. It does not replace the separate licenses of third-party components. Versions are pinned or constrained in the package manifests and lockfile; check the license files shipped with those exact dependency versions when redistributing a build.

## Optional scanner programs

These scanners are **not bundled** with the application. The user installs and runs them separately. Their licenses apply to those programs, not to this repository, and this project does not grant a license to redistribute them.

| Program | License | Upstream license |
| --- | --- | --- |
| Cisco Skill Scanner | Apache-2.0 | [LICENSE](https://github.com/cisco-ai-defense/skill-scanner/blob/main/LICENSE) |
| Semgrep CLI | LGPL-2.1 (the upstream repository may contain files with other notices) | [COPYRIGHT](https://github.com/semgrep/semgrep/blob/develop/COPYRIGHT) |
| Gitleaks | MIT | [LICENSE](https://github.com/gitleaks/gitleaks/blob/master/LICENSE) |
| OSV-Scanner | Apache-2.0 | [LICENSE](https://github.com/google/osv-scanner/blob/main/LICENSE) |

Use the official upstream distribution and review the license for the specific version you install. The scanner integration invokes a local CLI; it does not download these tools.

## Application dependencies

The desktop build includes or links third-party dependencies resolved by `frontend/package-lock.json`, `frontend/src-tauri/Cargo.toml`, and `backend/requirements*.txt`. These components retain their own terms. Direct dependencies include Vue (MIT), FastAPI (MIT), Uvicorn (BSD-3-Clause), Pydantic (MIT), PyInstaller (GPL-2.0-or-later with the Bootloader exception; some PyInstaller runtime-hook files are Apache-2.0), Tauri (MIT or Apache-2.0), `tauri-plugin-shell` (MIT or Apache-2.0), Serde (MIT or Apache-2.0), and UUID (MIT or Apache-2.0). Transitive dependencies can have additional license terms.

The project does not modify PyInstaller. The upstream exception permits distributing applications produced by PyInstaller, subject to the licenses of the bundled dependencies. Review the upstream license text before redistributing modified PyInstaller components.

Upstream license references:

- [Vue](https://github.com/vuejs/core/blob/main/LICENSE)
- [FastAPI](https://github.com/fastapi/fastapi/blob/master/LICENSE)
- [Uvicorn](https://github.com/encode/uvicorn/blob/master/LICENSE.md)
- [Pydantic](https://github.com/pydantic/pydantic/blob/main/LICENSE)
- [PyInstaller licensing](https://github.com/pyinstaller/pyinstaller/blob/develop/COPYING.txt)
- [Tauri licenses](https://github.com/tauri-apps/tauri)
- [tauri-plugin-shell licenses](https://github.com/tauri-apps/plugins-workspace)
- [Serde dual license](https://github.com/serde-rs/serde/blob/master/LICENSE-MIT)
- [UUID crate](https://github.com/uuid-rs/uuid)

This notice is an aid for review, not legal advice or a complete bill of materials. Verify the exact resolved versions and their bundled notices before making a commercial distribution.
