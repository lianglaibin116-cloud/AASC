# Local CSV helper

Read an explicitly selected CSV file and summarize the row counts. Save the result in the selected output directory.
