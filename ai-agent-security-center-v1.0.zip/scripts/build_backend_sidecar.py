"""Build the Python API as a Tauri sidecar for the current host platform."""

from __future__ import annotations

import os
import platform
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def rust_host_triple() -> str:
    result = subprocess.run(
        ["rustc", "-vV"], check=True, capture_output=True, text=True
    )
    for line in result.stdout.splitlines():
        if line.startswith("host:"):
            return line.partition(":")[2].strip()
    raise RuntimeError("rustc -vV did not report a host target triple")


def main() -> None:
    if platform.system() not in {"Windows", "Darwin"}:
        raise SystemExit("Desktop sidecar builds currently support Windows and macOS hosts")

    target = rust_host_triple()
    suffix = ".exe" if platform.system() == "Windows" else ""
    rules = ROOT / "backend" / "security_center" / "semgrep-rules.yml"
    launcher = ROOT / "backend" / "launcher.py"
    output_dir = ROOT / "frontend" / "src-tauri" / "binaries"

    with tempfile.TemporaryDirectory(prefix="aasc-pyinstaller-") as temp_dir:
        temp = Path(temp_dir)
        command = [
            sys.executable,
            "-m",
            "PyInstaller",
            "--clean",
            "--noconfirm",
            "--noconsole",
            "--onefile",
            "--name",
            "aasc-backend",
            "--paths",
            str(ROOT / "backend"),
            "--collect-all",
            "fastapi",
            "--collect-all",
            "starlette",
            "--collect-all",
            "uvicorn",
            "--collect-all",
            "pydantic",
            "--collect-submodules",
            "security_center",
            "--add-data",
            f"{rules}{os.pathsep}security_center",
            "--distpath",
            str(temp / "dist"),
            "--workpath",
            str(temp / "build"),
            "--specpath",
            str(temp),
            str(launcher),
        ]
        subprocess.run(command, cwd=ROOT, check=True)
        built = temp / "dist" / f"aasc-backend{suffix}"
        if not built.is_file():
            raise FileNotFoundError(f"PyInstaller output was not created: {built}")

        output_dir.mkdir(parents=True, exist_ok=True)
        destination = output_dir / f"aasc-backend-{target}{suffix}"
        shutil.copy2(built, destination)
        if platform.system() == "Darwin":
            destination.chmod(destination.stat().st_mode | 0o111)
        print(f"Created Tauri sidecar: {destination}")


if __name__ == "__main__":
    main()
