# Changelog

## 1.0.0

- Initial V1 desktop application for macOS and Windows 11.
- Static review of public GitHub commits and authorized local Skills/MCP configuration.
- Built-in detection rules, optional local scanner integrations, prioritized and detailed reports, and SQLite scan history.
- No runtime monitoring, dynamic sandbox, MCP gateway, or automatic blocking.
