from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import sqlite3
import stat
import subprocess
import tempfile
import time
import urllib.error
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath
from typing import Any

from .reporting import build_report

MAX_FILES = 5000
MAX_FILE_BYTES = 2 * 1024 * 1024
MAX_ARCHIVE_BYTES = 50 * 1024 * 1024
MAX_UNPACKED_BYTES = 100 * 1024 * 1024
MAX_FINDINGS = 1000
TEXT_EXT = {".md", ".txt", ".py", ".js", ".ts", ".tsx", ".jsx", ".sh", ".ps1", ".bat", ".cmd", ".json", ".yaml", ".yml", ".toml", ".ini", ".cfg", ".xml", ".env"}
CONFIG_NAMES = {"mcp.json", "settings.json", "settings.local.json", ".cursor/mcp.json", "claude_desktop_config.json", "config.toml", "package.json", "requirements.txt", "pyproject.toml"}
LOCK_NAMES = {"package-lock.json", "pnpm-lock.yaml", "yarn.lock", "uv.lock", "poetry.lock", "Cargo.lock", "go.sum", "Pipfile.lock"}
SEVERITY = {"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def safe_text(value: Any, limit: int = 280) -> str:
    s = str(value or "").replace("\x00", " ").replace("\r", " ").replace("\n", " ")[:limit]
    s = re.sub(r"(?i)((?:api[_-]?key|token|password|secret|authorization|bearer)\s*[:=]\s*)[\"']?[^\s,\"']+", r"\1[REDACTED]", s)
    s = re.sub(r"(?i)(gh[pousr]_[A-Za-z0-9_]{15,}|sk-[A-Za-z0-9_-]{15,}|AKIA[0-9A-Z]{16})", "[REDACTED]", s)
    s = re.sub(r"(?i)([?&](?:token|key|secret|password)=)[^&\s]+", r"\1[REDACTED]", s)
    s = re.sub(r"[A-Za-z0-9+/=_-]{48,}", "[REDACTED-LONG-VALUE]", s)
    return s


def finding(rule: str, severity: str, title: str, path: str, line: int, evidence: str, advice: str, scanner: str = "内置规则") -> dict:
    return {"rule": rule, "severity": severity, "title": title, "file": path, "line": int(line or 1), "evidence": safe_text(evidence), "advice": advice, "scanner": scanner}


RULES = [
    ("PROMPT_OVERRIDE", "high", "提示词试图覆盖上级指令", re.compile(r"(?i)(ignore (all |any )?(previous|prior|system|developer) (instructions|prompts)|忽略(之前|以上|系统|开发者).{0,12}(指令|提示)|you are now (the )?system|你现在是系统)") , "删除越权指令；明确 Skill 只描述任务步骤。"),
    ("PROMPT_SECRET", "critical", "提示词要求读取或发送秘密", re.compile(r"(?i)((read|读取|收集|获取|upload|上传|发送|exfiltrat).{0,80}(\.ssh|\.aws|\.env|api.?key|token|密钥|凭据|环境变量)|(\.ssh|\.aws|\.env|api.?key|token|密钥|凭据).{0,80}(send|post|upload|发送|上传))"), "移除秘密读取与传输要求，改为最小权限输入。"),
    ("SENSITIVE_PATH", "high", "访问敏感文件路径", re.compile(r"(?i)(\.ssh[/\\]|id_rsa|id_ed25519|\.aws[/\\]credentials|\.env\b|AppData[/\\]Roaming[/\\].{0,30}(?:Claude|Cursor)|keychain)"), "确认是否确需读取；限制路径并避免处理凭据。"),
    ("EXFIL_NETWORK", "high", "可能的对外发送", re.compile(r"(?i)(curl\s+.{0,100}(?:-d|--data|--upload-file|-T)\b|requests\.(post|put)\s*\(|fetch\s*\(.{0,120}method\s*:\s*['\"]POST|Invoke-RestMethod|urllib\.request\.Request\s*\()"), "核实目标域名和发送内容；默认禁用外传并要求明确授权。"),
    ("DANGEROUS_COMMAND", "high", "危险命令或下载后执行", re.compile(r"(?i)(curl\b.{0,120}\|\s*(?:ba)?sh\b|wget\b.{0,120}\|\s*(?:ba)?sh\b|iwr\b.{0,120}\|\s*iex\b|Invoke-Expression\b|rm\s+-rf\b|Remove-Item\b.{0,80}-Recurse|format\s+[a-z]:|del\s+/[sq])"), "移除自动执行或删除操作；改为可审查的手动步骤。"),
    ("SHELL_EXEC", "medium", "脚本可执行外部命令", re.compile(r"(?i)(subprocess\.(?:run|Popen|call)|os\.system\s*\(|child_process\.(?:exec|spawn)|eval\s*\(|exec\s*\()"), "检查输入来源和参数；禁用 shell 拼接并固定允许的命令。"),
]


def relevant(path: Path) -> bool:
    return path.name == "SKILL.md" or path.suffix.lower() in TEXT_EXT or path.name in LOCK_NAMES or path.name in CONFIG_NAMES


def _iter_files(root: Path):
    count = 0
    for base, dirs, names in os.walk(root, followlinks=False):
        dirs[:] = sorted(d for d in dirs if d not in {".git", "node_modules", ".venv", "venv", "dist", "build", "__pycache__"} and not (Path(base) / d).is_symlink())
        for name in sorted(names):
            p = Path(base) / name
            if p.is_symlink() or not p.is_file():
                continue
            count += 1
            if count > MAX_FILES:
                raise ValueError(f"文件数量超过限制 {MAX_FILES}")
            yield p


def audit_tree(root: Path) -> tuple[list[dict], list[dict], list[dict]]:
    findings, files, assets = [], [], []
    for path in _iter_files(root):
        rel = path.relative_to(root).as_posix()
        size = path.stat().st_size
        if not relevant(path):
            continue
        if size > MAX_FILE_BYTES:
            assets.append({"type": "跳过大文件", "path": rel, "detail": f"{size} bytes"})
            continue
        raw = path.read_bytes()
        files.append({"path": rel, "sha256": hashlib.sha256(raw).hexdigest(), "size": size})
        if b"\x00" in raw:
            continue
        body = raw.decode("utf-8", errors="replace")
        kind = "Skill" if path.name == "SKILL.md" else "依赖" if path.name in LOCK_NAMES or path.name in {"requirements.txt", "pyproject.toml", "package.json"} else "MCP 配置" if "mcp" in path.name.lower() or path.name == "claude_desktop_config.json" else "脚本/配置"
        assets.append({"type": kind, "path": rel, "detail": ""})
        for no, line in enumerate(body.splitlines(), 1):
            if len(findings) >= MAX_FINDINGS:
                break
            for rule, severity, title, pattern, advice in RULES:
                match = pattern.search(line)
                if match:
                    findings.append(finding(rule, severity, title, rel, no, match.group(0), advice))
        if path.suffix.lower() == ".json" and ("mcp" in path.name.lower() or path.name == "claude_desktop_config.json" or '"mcpServers"' in body):
            try:
                config = json.loads(body)
                if not isinstance(config, dict):
                    findings.append(finding("MCP_INVALID_SCHEMA", "low", "MCP 配置顶层不是对象", rel, 1, "JSON 顶层类型不符合 MCP 配置格式", "将配置顶层改为 JSON 对象。"))
                    continue
                servers = config.get("mcpServers", config.get("servers", {}))
                if isinstance(servers, dict):
                    for server_name, data in servers.items():
                        assets.append({"type": "MCP Server", "path": rel, "detail": safe_text(server_name, 80)})
                        if isinstance(data, dict) and isinstance(data.get("env"), dict) and data["env"]:
                            findings.append(finding("MCP_INLINE_ENV", "medium", "MCP 配置包含环境变量", rel, 1, f"server={server_name}; env keys={','.join(map(str, data['env'].keys()))}", "检查变量是否含明文凭据，改用系统安全存储。"))
            except (ValueError, TypeError):
                findings.append(finding("MCP_INVALID_JSON", "low", "MCP 配置不是有效 JSON", rel, 1, "JSON 解析失败", "修正 JSON 格式。"))
    return findings[:MAX_FINDINGS], files, assets


def local_candidates() -> list[Path]:
    home = Path.home()
    appdata = Path(os.environ.get("APPDATA", home / "AppData" / "Roaming"))
    userprofile = Path(os.environ.get("USERPROFILE", home))
    paths = [home / ".claude" / "skills", home / ".claude" / "settings.json", home / ".claude" / "settings.local.json", home / ".claude.json", home / ".codex" / "skills", home / ".codex" / "config.toml", home / ".cursor" / "skills", home / ".cursor" / "mcp.json", home / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json", appdata / "Claude" / "claude_desktop_config.json", userprofile / ".cursor" / "mcp.json"]
    return list(dict.fromkeys(paths))


def audit_local(custom_paths: list[str], authorized: bool, include_common: bool = True) -> tuple[list[dict], list[dict], list[dict], dict]:
    if not authorized:
        raise PermissionError("本地扫描需要用户明确授权")
    paths = (local_candidates() if include_common else []) + [Path(p).expanduser() for p in custom_paths]
    if not paths:
        raise ValueError("请选择常见路径或填写至少一个自定义路径")
    findings, files, assets, seen = [], [], [], set()
    scanned_roots: list[Path] = []
    # Scan a parent before its nested selections so overlapping roots never
    # produce duplicate findings or duplicate SQLite file keys.
    for source in sorted(paths, key=lambda path: (len(path.resolve(strict=False).parts), str(path))):
        resolved = source.resolve(strict=False)
        if resolved in seen or not source.exists() or source.is_symlink():
            continue
        seen.add(resolved)
        if any(root.is_dir() and resolved.is_relative_to(root) for root in scanned_roots):
            continue
        scanned_roots.append(resolved)
        if source.is_file():
            with tempfile.TemporaryDirectory(prefix="aasc-local-") as temp:
                # Copy only the chosen regular file, never a symlink. Scan the copy read-only.
                if source.stat().st_size > MAX_FILE_BYTES:
                    assets.append({"type": "跳过大文件", "path": str(source), "detail": "超过 2 MB"})
                    continue
                shutil.copyfile(source, Path(temp) / source.name)
                f, h, a = audit_tree(Path(temp))
        elif source.is_dir():
            f, h, a = audit_tree(source)
        else:
            continue
        prefix = str(source)
        for item in f + h + a:
            item["file" if "file" in item else "path"] = prefix + "/" + item.get("file", item.get("path", "")) if source.is_dir() else prefix
        findings.extend(f)
        files.extend(h)
        assets.extend(a)
    if not scanned_roots:
        raise ValueError("所选本地路径不存在、不可读取或是符号链接")
    return findings[:MAX_FINDINGS], files, assets, {"scanned_paths": [str(p) for p in scanned_roots], "include_common": include_common}


def stage_local_files(files: list[dict], sources: list[str], destination: Path) -> dict[str, str]:
    """Copy audited regular files for opt-in CLI scans; never run CLIs on originals."""
    source_paths = [Path(p) for p in sources]
    mapping = {}
    total = 0
    for item in files:
        original = Path(item["path"])
        resolved = original.resolve(strict=False)
        for index, source in enumerate(source_paths):
            try:
                rel = resolved.relative_to(source) if source.is_dir() else Path(source.name) if resolved == source else None
            except ValueError:
                rel = None
            if rel is None:
                continue
            target = destination / f"source-{index:02d}" / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(original, target)
            if hashlib.sha256(target.read_bytes()).hexdigest() != item["sha256"]:
                target.unlink(missing_ok=True)
                raise ValueError("本地文件在扫描期间发生变化，请重试")
            total += target.stat().st_size
            if total > MAX_UNPACKED_BYTES:
                raise ValueError("外部扫描暂存内容超过大小限制")
            mapping[target.relative_to(destination).as_posix()] = str(original)
            break
    return mapping


class GitHubRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        from urllib.parse import urlparse
        parsed = urlparse(newurl)
        if parsed.scheme != "https" or parsed.hostname not in {"api.github.com", "codeload.github.com"}:
            raise ValueError("GitHub 请求重定向到不受信任的主机")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


class RemoteFetchError(RuntimeError):
    """A transient or remote HTTP failure while fetching public GitHub data."""


def _download(url: str, limit: int) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "AI-Agent-Security-Center/1.0", "Accept": "application/vnd.github+json"})
    for attempt in range(3):
        try:
            opener = urllib.request.build_opener(GitHubRedirect())
            with opener.open(req, timeout=20) as response:
                data = response.read(limit + 1)
            if len(data) > limit:
                raise ValueError("下载超过大小限制")
            return data
        except urllib.error.HTTPError as exc:
            if exc.code in {429, 500, 502, 503, 504} and attempt < 2:
                time.sleep(0.75 * (attempt + 1))
                continue
            if exc.code == 404:
                raise ValueError("GitHub 仓库或指定 commit 不存在") from exc
            raise RemoteFetchError(f"GitHub 返回 HTTP {exc.code}；请检查网络或 API 限额后重试") from exc
        except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
            if attempt < 2:
                time.sleep(0.75 * (attempt + 1))
                continue
            raise RemoteFetchError("连接 GitHub 超时或失败；请检查网络及代理设置后重试") from exc
    raise RemoteFetchError("连接 GitHub 失败")


def github_source(url: str, commit: str, destination: Path) -> dict:
    match = re.fullmatch(r"https://github\.com/([A-Za-z0-9_.-]+)/([A-Za-z0-9_.-]+?)(?:\.git)?/?", url.strip())
    if not match:
        raise ValueError("仅支持公开 GitHub 仓库的标准 HTTPS 地址")
    if not re.fullmatch(r"[0-9a-fA-F]{40}", commit):
        raise ValueError("commit 必须是完整的 40 位 SHA")
    owner, repo = match.groups()
    if owner in {".", ".."} or repo in {".", ".."}:
        raise ValueError("仓库地址格式无效")
    base = f"https://api.github.com/repos/{owner}/{repo}"
    repo_info = json.loads(_download(base, 1024 * 1024))
    if repo_info.get("private") or repo_info.get("full_name", "").lower() != f"{owner}/{repo}".lower():
        raise ValueError("仓库不存在、非公开或来源不匹配")
    commit_info = json.loads(_download(base + f"/commits/{commit}", 1024 * 1024))
    sha = commit_info.get("sha", "")
    if sha.lower() != commit.lower():
        raise ValueError("commit 校验失败")
    archive = _download(f"https://codeload.github.com/{owner}/{repo}/zip/{sha}", MAX_ARCHIVE_BYTES)
    import io
    with zipfile.ZipFile(io.BytesIO(archive)) as zf:
        infos = zf.infolist()
        if len(infos) > MAX_FILES + 100:
            raise ValueError("压缩包文件数量超过限制")
        total = 0
        seen_targets = set()
        archive_root = None
        for info in infos:
            posix = PurePosixPath(info.filename)
            parts = posix.parts
            if archive_root is None and parts:
                archive_root = parts[0]
            if parts and parts[0] != archive_root:
                raise ValueError("压缩包包含多个根目录")
            if info.is_dir() and len(parts) == 1:
                continue
            if len(parts) < 2 or any(part in {"..", "."} for part in parts) or posix.is_absolute() or "\\" in info.filename or ":" in info.filename:
                raise ValueError("压缩包包含不安全路径")
            for part in parts[1:]:
                stem = part.split(".", 1)[0].upper()
                if part.rstrip(" .") != part or stem in {"CON", "PRN", "AUX", "NUL", *(f"COM{i}" for i in range(1, 10)), *(f"LPT{i}" for i in range(1, 10))} or any(ord(c) < 32 for c in part):
                    raise ValueError("压缩包包含不安全的 Windows 文件名")
            mode = (info.external_attr >> 16) & 0o170000
            if mode not in {0, stat.S_IFREG, stat.S_IFDIR}:
                raise ValueError("压缩包包含链接或特殊文件")
            if info.is_dir():
                continue
            key = "/".join(parts[1:]).casefold()
            if key in seen_targets:
                raise ValueError("压缩包包含重复文件名")
            seen_targets.add(key)
            total += info.file_size
            if total > MAX_UNPACKED_BYTES or info.file_size > MAX_FILE_BYTES * 10:
                raise ValueError("解压内容超过大小限制")
            target = destination.joinpath(*parts[1:])
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, target.open("wb") as dst:
                copied = 0
                while chunk := src.read(1024 * 1024):
                    copied += len(chunk)
                    if copied > info.file_size or copied > MAX_FILE_BYTES * 10:
                        raise ValueError("解压文件超过大小限制")
                    dst.write(chunk)
    return {"url": f"https://github.com/{owner}/{repo}", "commit": sha, "full_name": repo_info.get("full_name"), "default_branch": repo_info.get("default_branch"), "stars": repo_info.get("stargazers_count"), "updated_at": repo_info.get("updated_at"), "commit_date": commit_info.get("commit", {}).get("committer", {}).get("date"), "archive_sha256": hashlib.sha256(archive).hexdigest()}


def _external_findings(name: str, data: Any, root: Path) -> list[dict]:
    results = []
    if name == "Cisco Skill Scanner":
        groups = data if isinstance(data, list) else [data]
        rows = [f for group in groups if isinstance(group, dict) for f in group.get("findings", [])]
        for f in rows:
            results.append(finding(str(f.get("rule_id") or f.get("id") or "CISCO"), str(f.get("severity", "medium")).lower(), str(f.get("title") or "Cisco 发现"), str(f.get("file_path") or ""), f.get("line_number") or 1, f.get("snippet") or f.get("description") or "", "审查此发现并按 Cisco 规则说明修复。", name))
    elif name == "Semgrep":
        for row in data.get("results", []):
            extra = row.get("extra", {})
            results.append(finding(row.get("check_id", "SEMGREP"), str(extra.get("severity", "medium")).lower(), safe_text(extra.get("message", "Semgrep 发现"), 120), row.get("path", ""), row.get("start", {}).get("line", 1), extra.get("lines", ""), "审查命中代码，限制输入、文件和网络权限。", name))
    elif name == "Gitleaks":
        for row in data or []:
            results.append(finding(row.get("RuleID", "GITLEAKS"), "high", "疑似泄露凭据", row.get("File", ""), row.get("StartLine", 1), row.get("Description", "已隐去秘密值"), "吊销并轮换凭据，从源文件和历史中移除。", name))
    elif name == "OSV-Scanner":
        for source in data.get("results", []):
            path = source.get("source", {}).get("path", "")
            for package in source.get("packages", []):
                p = package.get("package", {})
                for vuln in package.get("vulnerabilities", []):
                    results.append(finding(vuln.get("id", "OSV"), "high", "依赖存在已知漏洞", path, 1, f"{p.get('name', '')}@{p.get('version', '')}: {vuln.get('id', '')}", "升级到修复版本并复扫。", name))
    for row in results:
        p = Path(str(row["file"]))
        if p.is_absolute():
            try:
                row["file"] = p.relative_to(root).as_posix()
            except ValueError:
                row["file"] = p.name
        if row["severity"] not in SEVERITY:
            row["severity"] = "medium"
    return results[:MAX_FINDINGS]


def external_scans(root: Path, enabled: list[str], allow_osv_network: bool) -> tuple[list[dict], list[dict]]:
    statuses, findings = [], []
    tools = [("Cisco Skill Scanner", "skill-scanner"), ("Semgrep", "semgrep"), ("Gitleaks", "gitleaks"), ("OSV-Scanner", "osv-scanner")]
    env = {k: v for k, v in os.environ.items() if k in {"PATH", "SystemRoot", "WINDIR", "TEMP", "TMP", "HOME", "USERPROFILE", "APPDATA"}}
    env.update({"SEMGREP_SEND_METRICS": "off", "SEMGREP_APP_TOKEN": "", "SKILL_SCANNER_LLM_API_KEY": "", "AI_DEFENSE_API_KEY": "", "VIRUSTOTAL_API_KEY": ""})
    for name, binary in tools:
        executable = shutil.which(binary)
        if name not in enabled:
            statuses.append({"name": name, "status": "未运行", "reason": "未选择"})
            continue
        if not executable:
            statuses.append({"name": name, "status": "未运行", "reason": "未安装"})
            continue
        if name == "OSV-Scanner" and not allow_osv_network:
            statuses.append({"name": name, "status": "未运行", "reason": "未授权依赖元数据联网查询"})
            continue
        if name == "Cisco Skill Scanner":
            all_skills = sorted(p.parent for p in root.rglob("SKILL.md") if not p.is_symlink())
            skills = all_skills[:100]
            if not skills:
                statuses.append({"name": name, "status": "未运行", "reason": "未发现 SKILL.md"})
                continue
            commands = [[executable, "scan", str(p), "--format", "json"] for p in skills]
        elif name == "Semgrep":
            rules = Path(__file__).with_name("semgrep-rules.yml")
            commands = [[executable, "scan", "--config", str(rules), "--json", "--metrics=off", str(root)]]
        elif name == "Gitleaks":
            commands = [[executable, "dir", "--report-format", "json", "--redact", str(root)]]
        else:
            commands = [[executable, "scan", "source", "-r", "--format", "json", str(root)]]
        try:
            count = 0
            for command in commands:
                proc = subprocess.run(command, capture_output=True, text=True, timeout=90, env=env, cwd=root, shell=False)
                if len(proc.stdout) > 5_000_000:
                    raise ValueError("扫描器输出过大")
                if proc.returncode not in {0, 1}:
                    raise ValueError(f"退出码 {proc.returncode}: {safe_text(proc.stderr, 100)}")
                data = json.loads(proc.stdout or "[]")
                rows = _external_findings(name, data, root)
                if name == "Cisco Skill Scanner":
                    skill_root = Path(command[2])
                    for row in rows:
                        if row["file"] and not (root / row["file"]).exists():
                            row["file"] = (skill_root / row["file"]).relative_to(root).as_posix()
                count += len(rows)
                findings.extend(rows)
            partial = name == "Cisco Skill Scanner" and len(all_skills) > 100
            statuses.append({"name": name, "status": "部分运行" if partial else "已运行", "reason": f"发现 {count} 项；只扫描前 100 个 Skill" if partial else f"发现 {count} 项"})
        except Exception as exc:
            statuses.append({"name": name, "status": "运行失败", "reason": safe_text(exc, 120)})
    return findings[:MAX_FINDINGS], statuses


class Store:
    def __init__(self, path: Path):
        self.path = path
        path.parent.mkdir(parents=True, exist_ok=True)
        with self._db() as db:
            db.executescript("""CREATE TABLE IF NOT EXISTS projects(id INTEGER PRIMARY KEY, kind TEXT NOT NULL, source TEXT NOT NULL, created_at TEXT NOT NULL, UNIQUE(kind,source));
            CREATE TABLE IF NOT EXISTS scans(id INTEGER PRIMARY KEY, project_id INTEGER NOT NULL, created_at TEXT NOT NULL, version TEXT, metadata TEXT NOT NULL, findings TEXT NOT NULL, assets TEXT NOT NULL, scanners TEXT NOT NULL, FOREIGN KEY(project_id) REFERENCES projects(id));
            CREATE TABLE IF NOT EXISTS files(scan_id INTEGER NOT NULL, path TEXT NOT NULL, sha256 TEXT NOT NULL, size INTEGER NOT NULL, PRIMARY KEY(scan_id,path), FOREIGN KEY(scan_id) REFERENCES scans(id));""")

    def _db(self):
        db = sqlite3.connect(self.path)
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA foreign_keys=ON")
        return db

    def save(self, kind: str, source: str, version: str, metadata: dict, findings: list[dict], files: list[dict], assets: list[dict], scanners: list[dict]) -> int:
        with self._db() as db:
            db.execute("INSERT OR IGNORE INTO projects(kind,source,created_at) VALUES(?,?,?)", (kind, source, now()))
            project_id = db.execute("SELECT id FROM projects WHERE kind=? AND source=?", (kind, source)).fetchone()[0]
            cur = db.execute("INSERT INTO scans(project_id,created_at,version,metadata,findings,assets,scanners) VALUES(?,?,?,?,?,?,?)", (project_id, now(), version, json.dumps(metadata), json.dumps(findings), json.dumps(assets), json.dumps(scanners)))
            scan_id = cur.lastrowid
            db.executemany("INSERT INTO files(scan_id,path,sha256,size) VALUES(?,?,?,?)", [(scan_id, f["path"], f["sha256"], f["size"]) for f in files])
            return scan_id

    def list_scans(self) -> list[dict]:
        with self._db() as db:
            rows = db.execute("SELECT scans.id, scans.created_at, scans.version, projects.kind, projects.source, scans.findings, scans.scanners FROM scans JOIN projects ON scans.project_id=projects.id ORDER BY scans.id DESC LIMIT 100").fetchall()
        summaries = []
        for row in rows:
            findings = json.loads(row["findings"])
            scanners = json.loads(row["scanners"])
            _, report = build_report(findings, scanners)
            summaries.append({"id": row["id"], "created_at": row["created_at"], "version": row["version"], "kind": row["kind"], "source": row["source"], "findings_count": len(findings), "priority_counts": report["priority_counts"], "scanners": scanners})
        return summaries

    def get_scan(self, scan_id: int) -> dict | None:
        with self._db() as db:
            row = db.execute("SELECT scans.*, projects.kind, projects.source FROM scans JOIN projects ON scans.project_id=projects.id WHERE scans.id=?", (scan_id,)).fetchone()
            if not row:
                return None
            files = [dict(r) for r in db.execute("SELECT path,sha256,size FROM files WHERE scan_id=? ORDER BY path", (scan_id,))]
        assets = json.loads(row["assets"])
        scanners = json.loads(row["scanners"])
        findings, report = build_report(json.loads(row["findings"]), scanners, assets)
        return {"id": row["id"], "created_at": row["created_at"], "version": row["version"], "kind": row["kind"], "source": row["source"], "metadata": json.loads(row["metadata"]), "findings": findings, "report": report, "assets": assets, "scanners": scanners, "files": files}
