#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use serde::Serialize;
use std::net::TcpListener;
use std::sync::Mutex;
use tauri::{Manager, State};
use tauri_plugin_shell::{process::CommandChild, ShellExt};

struct BackendState {
    base_url: String,
    api_token: String,
    child: Mutex<Option<CommandChild>>,
}

#[derive(Serialize)]
struct BackendConfig {
    base_url: String,
    api_token: String,
}

#[tauri::command]
fn backend_config(state: State<'_, BackendState>) -> BackendConfig {
    BackendConfig {
        base_url: state.base_url.clone(),
        api_token: state.api_token.clone(),
    }
}

fn main() {
    let app = tauri::Builder::default()
        .plugin(tauri_plugin_shell::init())
        .setup(|app| {
            if cfg!(debug_assertions) {
                app.manage(BackendState {
                    base_url: "http://127.0.0.1:8000".to_string(),
                    api_token: String::new(),
                    child: Mutex::new(None),
                });
                return Ok(());
            }

            // Reserve an unused loopback port for this app instance. The backend
            // binds only to 127.0.0.1 and requires the per-launch token below.
            let listener = TcpListener::bind(("127.0.0.1", 0))?;
            let port = listener.local_addr()?.port();
            drop(listener);
            let port_arg = port.to_string();
            let token = uuid::Uuid::new_v4().to_string();

            let mut command = app
                .shell()
                .sidecar("binaries/aasc-backend")?
                .args(["--port", port_arg.as_str()])
                .env_clear();
            for key in [
                "PATH", "SystemRoot", "WINDIR", "TEMP", "TMP", "TMPDIR", "HOME",
                "USERPROFILE", "APPDATA", "LOCALAPPDATA", "LANG", "LC_ALL",
            ] {
                if let Some(value) = std::env::var_os(key) {
                    command = command.env(key, value);
                }
            }
            let (mut events, child) = command
                .env("AASC_API_TOKEN", token.as_str())
                .set_process_group(true)
                .spawn()?;

            // Drain child output so its pipes cannot fill during long scans.
            tauri::async_runtime::spawn(async move {
                while events.recv().await.is_some() {}
            });

            app.manage(BackendState {
                base_url: format!("http://127.0.0.1:{port}"),
                api_token: token,
                child: Mutex::new(Some(child)),
            });
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![backend_config])
        .build(tauri::generate_context!())
        .expect("failed to build AI Agent Security Center");

    app.run(|handle, event| {
        if matches!(event, tauri::RunEvent::Exit) {
            if let Some(state) = handle.try_state::<BackendState>() {
                if let Ok(mut child) = state.child.lock() {
                    if let Some(child) = child.take() {
                        let _ = child.kill();
                    }
                }
            }
        }
    });
}
