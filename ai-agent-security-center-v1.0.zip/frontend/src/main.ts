import { createApp } from 'vue'
import App from './App.vue'
import './style.css'
import './report.css'
import './desktop.css'
createApp(App).mount('#app')
