"""Explainable review order for static findings. This is triage, not a safety verdict."""

from __future__ import annotations

from collections import Counter, defaultdict
import csv
import io
from pathlib import PurePath

PRIORITY_LABELS = {"focus": "优先复核", "review": "常规复核", "context": "参考信息"}
PRIORITY_ORDER = {"focus": 0, "review": 1, "context": 2}
BASE_SCORE = {"critical": 75, "high": 60, "medium": 40, "low": 20, "info": 10}
CODE_SUFFIXES = {".py", ".js", ".jsx", ".ts", ".tsx", ".sh", ".ps1", ".bat", ".cmd"}
DOCUMENT_NAMES = {"readme.md", "changelog.md", "contributing.md", "security.md", "setup.md", "license.md"}
CONTEXT_PARTS = {"tests", "test", "fixtures", "examples", "example", "samples", "sample", "docs", "documentation"}


def _path_context(path: str) -> tuple[bool, bool, bool, bool]:
    normalized = path.replace("\\", "/").lower()
    parts = tuple(p for p in normalized.split("/") if p)
    name = parts[-1] if parts else ""
    active_instruction = name in {"skill.md", "agents.md", "claude.md"} or "/.claude/commands/" in f"/{normalized}" or "/.codex/skills/" in f"/{normalized}"
    documentation_or_test = name in DOCUMENT_NAMES or any(p in CONTEXT_PARTS for p in parts[:-1])
    executable = PurePath(name).suffix in CODE_SUFFIXES
    configuration = name in {"mcp.json", "claude_desktop_config.json", "settings.json", "config.toml"}
    return active_instruction, documentation_or_test, executable, configuration


def _category(rule: str, scanner: str) -> str:
    if scanner == "OSV-Scanner" or rule.startswith("OSV"):
        return "依赖漏洞"
    if scanner == "Gitleaks" or rule == "SENSITIVE_PATH":
        return "敏感信息"
    if rule.startswith("PROMPT") or scanner == "Cisco Skill Scanner":
        return "智能体指令"
    if rule == "EXFIL_NETWORK":
        return "对外通信"
    if rule in {"SHELL_EXEC", "DANGEROUS_COMMAND"} or scanner == "Semgrep":
        return "命令与代码执行"
    if rule.startswith("MCP"):
        return "MCP 配置"
    return "其他"


def _assess(item: dict, same_file_rules: set[str]) -> dict:
    rule = str(item.get("rule", ""))
    scanner = str(item.get("scanner", ""))
    active, context, executable, configuration = _path_context(str(item.get("file", "")))
    linked_flow = "EXFIL_NETWORK" in same_file_rules and bool(same_file_rules & {"SENSITIVE_PATH", "PROMPT_SECRET"})
    score = BASE_SCORE.get(str(item.get("severity", "medium")).lower(), 40)
    if scanner == "Gitleaks":
        score += 20
    if scanner == "OSV-Scanner":
        score += 10
    if active and rule in {"PROMPT_OVERRIDE", "PROMPT_SECRET", "DANGEROUS_COMMAND"}:
        score += 15
    elif active and rule == "SENSITIVE_PATH":
        score += 8
    if executable and rule in {"PROMPT_SECRET", "DANGEROUS_COMMAND", "EXFIL_NETWORK"}:
        score += 10
    if configuration and rule == "MCP_INLINE_ENV":
        score += 10
    if linked_flow:
        score += 15
    if context and scanner not in {"Gitleaks", "OSV-Scanner"}:
        score -= 55
    priority = "focus" if score >= 70 else "review" if score >= 40 else "context"
    if context and scanner not in {"Gitleaks", "OSV-Scanner"}:
        why = "位于文档、示例或测试文件；通常优先级较低，仍需确认是否被实际执行。"
    elif linked_flow:
        why = "同一文件同时命中敏感信息和对外通信线索，需要先核实数据流向。"
    elif scanner == "Gitleaks":
        why = "外部扫描器报告疑似凭据，应核实并考虑轮换。"
    elif scanner == "OSV-Scanner":
        why = "外部扫描器报告已知依赖漏洞，应核对受影响版本。"
    elif active:
        why = "位于智能体指令或 Skill 文件，可能影响后续工具调用；需阅读上下文。"
    elif rule == "SHELL_EXEC":
        why = "检测到外部命令调用；单独命中不代表恶意，重点检查参数来源。"
    elif rule == "SENSITIVE_PATH":
        why = "涉及敏感路径；需确认它是在读取文件，还是仅作安全说明。"
    elif executable:
        why = "位于可执行脚本；需确认调用条件、输入和目标。"
    elif configuration:
        why = "位于配置文件；需核实凭据和权限设置。"
    else:
        why = "静态规则命中；需结合文件上下文判断。"
    return {**item, "priority": priority, "priority_label": PRIORITY_LABELS[priority], "priority_reason": why, "category": _category(rule, scanner), "_rank": score}


def build_report(findings: list[dict], scanners: list[dict], assets: list[dict] | None = None) -> tuple[list[dict], dict]:
    by_file_rules: dict[str, set[str]] = defaultdict(set)
    for item in findings:
        by_file_rules[str(item.get("file", ""))].add(str(item.get("rule", "")))
    assessed = [_assess(item, by_file_rules[str(item.get("file", ""))]) for item in findings]
    assessed.sort(key=lambda item: (PRIORITY_ORDER[item["priority"]], -item["_rank"], str(item.get("file", "")), int(item.get("line") or 0)))
    source_counts = Counter(str(item.get("scanner") or "内置规则") for item in assessed)
    builtin_count = source_counts.get("内置规则", 0)
    external_count = len(assessed) - builtin_count
    counts = {key: sum(item["priority"] == key for item in assessed) for key in PRIORITY_LABELS}
    file_counts = {key: len({str(item.get("file", "")) for item in assessed if item["priority"] == key}) for key in PRIORITY_LABELS}
    categories = [{"name": name, "count": count} for name, count in Counter(item["category"] for item in assessed).most_common()]
    groups: dict[str, list[dict]] = defaultdict(list)
    for item in assessed:
        groups[str(item.get("file", ""))].append(item)
    top_files = []
    for path, rows in groups.items():
        representative = rows[0]
        top_files.append({
            "file": path,
            "priority": representative["priority"],
            "priority_label": representative["priority_label"],
            "rank": representative["_rank"],
            "finding_count": len(rows),
            "priority_finding_count": sum(row["priority"] == representative["priority"] for row in rows),
            "rules": list(dict.fromkeys(str(row.get("rule", "")) for row in rows))[:5],
            "first_line": representative.get("line", 1),
            "reason": representative["priority_reason"],
            "advice": representative.get("advice", ""),
        })
    top_files.sort(key=lambda item: (PRIORITY_ORDER[item["priority"]], -item["rank"], -len(item["rules"]), -item["finding_count"], item["file"]))
    not_run = [s for s in scanners if s.get("status") != "已运行"]
    requested_incomplete = [s for s in not_run if s.get("reason") != "未选择"]
    unselected_count = sum(s.get("reason") == "未选择" for s in scanners)
    if counts["focus"]:
        headline = f"先复核 {file_counts['focus']} 个文件中的 {counts['focus']} 条重点线索"
    elif counts["review"]:
        headline = f"建议复核 {file_counts['review']} 个文件中的 {counts['review']} 条线索"
    elif assessed:
        headline = "本次命中项主要来自文档、示例或测试文件"
    else:
        headline = "本次未命中规则，仍需结合扫描覆盖范围判断"
    report = {
        "headline": headline,
        "total_findings": len(assessed),
        "affected_files": len(groups),
        "asset_count": len(assets or []),
        "builtin_findings": builtin_count,
        "external_findings": external_count,
        "finding_sources": [{"name": name, "count": count} for name, count in source_counts.most_common()],
        "source_note": (
            f"本报告依据已运行的内置静态规则（{builtin_count} 条线索）和外部扫描器（{external_count} 条线索）生成。未运行的扫描器没有参与检测。"
            if external_count else
            f"本报告仅依据已运行的内置静态规则生成，共 {builtin_count} 条线索；未运行的外部扫描器没有参与检测。"
        ),
        "priority_counts": counts,
        "priority_file_counts": file_counts,
        "categories": categories,
        "top_files": top_files[:8],
        "unrun_scanners": not_run,
        "coverage_note": (
            f"已选择的 {len(requested_incomplete)} 个外部扫描器未完成；另有 {unselected_count} 个未选择。未完成的检查不计为通过。"
            if requested_incomplete else
            f"本次仅使用内置规则；{unselected_count} 个外部扫描器未选择。" if unselected_count == len(scanners) and scanners else
            f"选定的外部扫描器均已运行；另有 {unselected_count} 个未选择。" if unselected_count else
            "选定的外部扫描器均已运行。"
        ),
        "method_note": "优先级依据文件用途、规则类型和同文件线索自动排序，只决定复核顺序；不代表漏洞已确认，也不代表低优先级项可以直接忽略。",
    }
    for item in assessed:
        item.pop("_rank", None)
    return assessed, report


def summary_markdown(scan: dict) -> str:
    report = scan["report"]
    counts = report["priority_counts"]
    lines = [
        f"# AI Agent Security Center 总结报告 #{scan['id']}",
        "",
        f"来源：{scan['source']}",
        f"版本：{scan['version']}",
        f"扫描时间：{scan['created_at']}",
        "",
        "## 结论与优先级",
        "",
        report["headline"],
        "",
        "## 报告来源",
        "",
        report["source_note"],
        "",
        f"- 优先复核：{counts['focus']} 条 / {report['priority_file_counts']['focus']} 个文件",
        f"- 常规复核：{counts['review']} 条 / {report['priority_file_counts']['review']} 个文件",
        f"- 参考信息：{counts['context']} 条 / {report['priority_file_counts']['context']} 个文件",
        f"- 总计：{report['total_findings']} 条规则命中，涉及 {report['affected_files']} 个文件；盘点 {report['asset_count']} 项资产",
        "",
        report["method_note"],
        "",
        "## 建议先看的文件",
        "",
    ]
    if not report["top_files"]:
        lines.append("本次没有规则命中。")
    for item in report["top_files"]:
        file_name = str(item["file"]).replace("`", "\\`").replace("\n", " ")
        lines.extend([
            f"### {item['priority_label']}：`{file_name}`",
            "",
            f"本优先级 {item['priority_finding_count']} 条 / 文件共 {item['finding_count']} 条；首条位置第 {item['first_line']} 行；规则：{', '.join(item['rules'])}",
            "",
            f"原因：{item['reason']}",
            f"建议：{item['advice']}",
            "",
        ])
    lines.extend(["## 扫描器覆盖", "", f"- 内置静态规则：已运行（发现 {report['builtin_findings']} 条线索）"])
    for scanner in scan["scanners"]:
        lines.append(f"- {scanner['name']}：{scanner['status']}（{scanner['reason']}）")
    lines.extend(["", report["coverage_note"], "", "完整证据、文件和行号请查看详细列表。V1 仅做静态和配置审计。", ""])
    return "\n".join(lines)


def details_csv(scan: dict) -> str:
    buffer = io.StringIO(newline="")
    writer = csv.writer(buffer)
    columns = ["priority_label", "severity", "category", "title", "file", "line", "rule", "scanner", "evidence", "advice", "priority_reason"]
    writer.writerow(["复核优先级", "规则级别", "类别", "标题", "文件", "行号", "规则", "扫描器", "证据（已脱敏）", "修复建议", "排序依据"])
    for item in scan["findings"]:
        row = []
        for key in columns:
            value = str(item.get(key, ""))
            if value.lstrip().startswith(("=", "+", "-", "@")):
                value = "'" + value
            row.append(value)
        writer.writerow(row)
    return "\ufeff" + buffer.getvalue()
