from __future__ import annotations

import os
import tempfile
from pathlib import Path
from typing import Literal

from fastapi import FastAPI, Header, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi.responses import Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .core import RemoteFetchError, Store, audit_local, audit_tree, external_scans, github_source, local_candidates, stage_local_files
from .reporting import details_csv, summary_markdown


def default_db() -> Path:
    explicit = os.environ.get("AASC_DB")
    if explicit:
        return Path(explicit)
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    else:
        base = Path.home() / "Library" / "Application Support" if os.uname().sysname == "Darwin" else Path.home() / ".local" / "share"
    return base / "AI Agent Security Center" / "history.sqlite3"


store = Store(default_db())
app = FastAPI(title="AI Agent Security Center", version="1.0.0", description="本地静态与配置审计；不执行仓库内容。")
ALLOWED_ORIGINS = {"http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:8000", "http://127.0.0.1:8000", "tauri://localhost", "https://tauri.localhost", "http://tauri.localhost"}
API_TOKEN = os.environ.get("AASC_API_TOKEN", "")
app.add_middleware(CORSMiddleware, allow_origins=sorted(ALLOWED_ORIGINS), allow_credentials=False, allow_methods=["GET", "POST"], allow_headers=["Content-Type", "X-AASC-Request", "X-AASC-Consent", "X-AASC-Token"])


@app.middleware("http")
async def guard_origin(request: Request, call_next):
    if API_TOKEN and request.method != "OPTIONS" and request.headers.get("x-aasc-token") != API_TOKEN:
        return JSONResponse({"detail": "本机桌面会话校验失败"}, status_code=403)
    if request.method == "POST":
        origin = request.headers.get("origin")
        if origin and origin not in ALLOWED_ORIGINS:
            return JSONResponse({"detail": "不允许的页面来源"}, status_code=403)
        if request.headers.get("x-aasc-request") != "1":
            return JSONResponse({"detail": "缺少本地请求标记"}, status_code=403)
    return await call_next(request)


class RepoScan(BaseModel):
    url: str
    commit: str
    external: list[Literal["Cisco Skill Scanner", "Semgrep", "Gitleaks", "OSV-Scanner"]] = Field(default_factory=list)
    allow_osv_network: bool = False


class LocalScan(BaseModel):
    authorized: bool = False
    include_common: bool = False
    custom_paths: list[str] = Field(default_factory=list, max_length=20)
    external: list[Literal["Cisco Skill Scanner", "Semgrep", "Gitleaks", "OSV-Scanner"]] = Field(default_factory=list)
    allow_osv_network: bool = False


@app.get("/api/health")
def health():
    return {"status": "ok", "mode": "static-only", "version": "1.0.0"}


@app.get("/api/local/candidates")
def candidates():
    return [{"path": str(path), "exists": path.exists(), "type": "dir" if path.is_dir() else "file"} for path in local_candidates()]


@app.post("/api/scans/repo")
def scan_repo(body: RepoScan):
    try:
        with tempfile.TemporaryDirectory(prefix="aasc-repo-") as temp:
            root = Path(temp)
            metadata = github_source(body.url, body.commit, root)
            findings, files, assets = audit_tree(root)
            additional, scanners = external_scans(root, body.external, body.allow_osv_network)
            findings.extend(additional)
        scan_id = store.save("github", metadata["url"], metadata["commit"], metadata, findings, files, assets, scanners)
        return store.get_scan(scan_id)
    except RemoteFetchError as exc:
        raise HTTPException(502, str(exc)) from exc
    except (ValueError, OSError, PermissionError) as exc:
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:
        # Do not surface URLs, tokens, or other raw exception data from network libraries.
        raise HTTPException(502, f"GitHub 获取或扫描失败：{type(exc).__name__}") from exc


@app.post("/api/scans/local")
def scan_local(body: LocalScan, x_aasc_consent: str | None = Header(default=None)):
    if not body.authorized or x_aasc_consent != "local-read-only":
        raise HTTPException(403, "需要用户明确授权本地只读扫描")
    try:
        findings, files, assets, metadata = audit_local(body.custom_paths, True, body.include_common)
        if body.external:
            with tempfile.TemporaryDirectory(prefix="aasc-local-cli-") as temp:
                root = Path(temp)
                mapping = stage_local_files(files, metadata["scanned_paths"], root)
                extra, scanners = external_scans(root, body.external, body.allow_osv_network)
                for row in extra:
                    row["file"] = mapping.get(row["file"], row["file"])
                findings.extend(extra)
        else:
            scanners = [{"name": name, "status": "未运行", "reason": "未选择"} for name in ("Cisco Skill Scanner", "Semgrep", "Gitleaks", "OSV-Scanner")]
        scan_id = store.save("local", "本机 Skills/MCP 盘点", "local", metadata, findings, files, assets, scanners)
        return store.get_scan(scan_id)
    except (ValueError, OSError, PermissionError) as exc:
        raise HTTPException(400, str(exc)) from exc
    except Exception as exc:
        raise HTTPException(500, f"本地扫描失败：{type(exc).__name__}") from exc


@app.get("/api/scans")
def scans():
    return store.list_scans()


@app.get("/api/scans/{scan_id}")
def scan_detail(scan_id: int):
    item = store.get_scan(scan_id)
    if not item:
        raise HTTPException(404, "扫描记录不存在")
    return item


@app.get("/api/scans/{scan_id}/summary.md")
def export_summary(scan_id: int):
    item = store.get_scan(scan_id)
    if not item:
        raise HTTPException(404, "扫描记录不存在")
    return Response(summary_markdown(item), media_type="text/markdown; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="aasc-summary-{scan_id}.md"'})


@app.get("/api/scans/{scan_id}/details.csv")
def export_details(scan_id: int):
    item = store.get_scan(scan_id)
    if not item:
        raise HTTPException(404, "扫描记录不存在")
    return Response(details_csv(item), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": f'attachment; filename="aasc-details-{scan_id}.csv"'})


frontend_dist = Path(__file__).resolve().parents[2] / "frontend" / "dist"
if frontend_dist.exists():
    app.mount("/", StaticFiles(directory=frontend_dist, html=True), name="frontend")
