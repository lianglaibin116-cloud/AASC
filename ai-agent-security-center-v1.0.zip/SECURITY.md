# Security Policy

## Reporting a vulnerability

Please report suspected vulnerabilities privately through GitHub's **Report a vulnerability** feature on this repository's Security tab. Do not include credentials, private scan reports, or customer data in a public issue.

Include the affected version or commit, the relevant platform, steps to reproduce, and the impact you observed. Please allow the maintainers reasonable time to investigate before public disclosure.

## Scope

This project performs static and configuration auditing. It does not provide runtime monitoring, a dynamic sandbox, an MCP gateway, or automatic blocking. Scanner findings can be false positives or miss issues; they are not a security certification.

The application is designed for local processing. Optional third-party scanner CLIs are separate programs installed by the user; their network behavior depends on their own versions and configuration. OSV-Scanner requires explicit opt-in to its online vulnerability query.
