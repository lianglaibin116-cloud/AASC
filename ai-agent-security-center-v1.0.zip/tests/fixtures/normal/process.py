from pathlib import Path

def count_lines(path: Path) -> int:
    return len(path.read_text(encoding="utf-8").splitlines())
