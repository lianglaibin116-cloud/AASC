from security_center.reporting import build_report, details_csv, summary_markdown


def entry(rule: str, severity: str, file: str, line: int = 1, scanner: str = "内置规则") -> dict:
    return {"rule": rule, "severity": severity, "title": rule, "file": file, "line": line, "evidence": rule, "advice": "人工核查", "scanner": scanner}


def test_summary_prioritizes_active_skill_and_demotes_document_examples():
    findings = [
        entry("PROMPT_SECRET", "critical", ".claude/commands/send.md"),
        entry("DANGEROUS_COMMAND", "high", "README.md"),
        entry("SHELL_EXEC", "medium", "tests/test_runner.py"),
        entry("SHELL_EXEC", "medium", "tools/runner.py"),
    ]
    detailed, report = build_report(findings, [{"name": "Semgrep", "status": "未运行", "reason": "未安装"}])
    priorities = {row["file"]: row["priority"] for row in detailed}
    assert priorities[".claude/commands/send.md"] == "focus"
    assert priorities["tools/runner.py"] == "review"
    assert priorities["README.md"] == "context"
    assert priorities["tests/test_runner.py"] == "context"
    assert report["priority_counts"] == {"focus": 1, "review": 1, "context": 2}
    assert report["builtin_findings"] == 4
    assert report["external_findings"] == 0
    assert "内置静态规则" in report["source_note"]
    assert report["top_files"][0]["file"] == ".claude/commands/send.md"
    assert "未完成" in report["coverage_note"]


def test_combined_sensitive_path_and_network_signal_gets_focus():
    findings = [
        entry("SENSITIVE_PATH", "high", "src/collector.py", 4),
        entry("EXFIL_NETWORK", "high", "src/collector.py", 8),
    ]
    detailed, report = build_report(findings, [], [])
    assert all(row["priority"] == "focus" for row in detailed)
    assert report["priority_file_counts"]["focus"] == 1
    assert report["top_files"][0]["finding_count"] == 2


def test_external_secret_remains_high_priority_in_test_fixture():
    detailed, report = build_report([entry("generic-api-key", "high", "tests/fixtures/sample.env", scanner="Gitleaks")], [])
    assert detailed[0]["priority"] == "focus"
    assert report["builtin_findings"] == 0
    assert report["external_findings"] == 1
    assert report["finding_sources"] == [{"name": "Gitleaks", "count": 1}]


def test_both_exports_and_spreadsheet_formula_guard():
    detailed, report = build_report([entry("PROMPT_SECRET", "critical", "=HYPERLINK(test).md")], [])
    scan = {"id": 7, "source": "example", "version": "abc", "created_at": "2026-10-18", "findings": detailed, "report": report, "scanners": []}
    markdown = summary_markdown(scan)
    csv = details_csv(scan)
    assert "总结报告 #7" in markdown
    assert "内置静态规则：已运行" in markdown
    assert "建议先看的文件" in markdown
    assert "'=HYPERLINK(test).md" in csv
    assert csv.startswith("\ufeff")
