<script setup lang="ts">
import { computed, nextTick, onMounted, ref } from 'vue'

declare global {
  interface Window {
    __TAURI__?: { core: { invoke<T>(command: string): Promise<T> } }
  }
}

type Priority = 'focus' | 'review' | 'context'
type Finding = { rule: string; severity: string; title: string; file: string; line: number; evidence: string; advice: string; scanner: string; priority: Priority; priority_label: string; priority_reason: string; category: string }
type Asset = { type: string; path: string; detail: string }
type Scanner = { name: string; status: string; reason: string }
type FileHash = { path: string; sha256: string; size: number }
type ReportFile = { file: string; priority: Priority; priority_label: string; finding_count: number; priority_finding_count: number; rules: string[]; first_line: number; reason: string; advice: string }
type Report = { headline: string; total_findings: number; affected_files: number; asset_count: number; builtin_findings: number; external_findings: number; finding_sources: {name:string;count:number}[]; source_note: string; priority_counts: Record<Priority, number>; priority_file_counts: Record<Priority, number>; categories: {name:string;count:number}[]; top_files: ReportFile[]; coverage_note: string; method_note: string; unrun_scanners: Scanner[] }
type Scan = { id: number; created_at: string; kind: string; source: string; version: string; metadata: Record<string, unknown>; findings: Finding[]; report: Report; assets: Asset[]; scanners: Scanner[]; files: FileHash[] }
type Candidate = { path: string; exists: boolean; type: string }
const API = ref('http://127.0.0.1:8000')
const apiToken = ref('')
const tab = ref<'repo' | 'local' | 'history'>('repo')
const url = ref('')
const commit = ref('')
const selected = ref<string[]>([])
const osvConsent = ref(false)
const localSelected = ref<string[]>([])
const localOsvConsent = ref(false)
const localConsent = ref(false)
const includeCommon = ref(false)
const customPaths = ref('')
const candidates = ref<Candidate[]>([])
const history = ref<{ id: number; created_at: string; kind: string; source: string; version: string; findings_count: number; priority_counts: Record<Priority,number> }[]>([])
const scan = ref<Scan | null>(null)
const busy = ref(false)
const error = ref('')
const resultView = ref<'summary' | 'details'>('summary')
const detailSection = ref<'findings' | 'assets' | 'hashes'>('findings')
const priorityFilter = ref<'all' | Priority>('focus')
const selectedFile = ref('')
const detailQuery = ref('')
const scannedPaths = computed(() => {
  const value = scan.value?.metadata.scanned_paths
  return Array.isArray(value) ? value.filter((path): path is string => typeof path === 'string') : []
})
const filteredFindings = computed(() => (scan.value?.findings || []).filter(item => {
  if (priorityFilter.value !== 'all' && item.priority !== priorityFilter.value) return false
  if (selectedFile.value && item.file !== selectedFile.value) return false
  const query = detailQuery.value.trim().toLocaleLowerCase()
  return !query || [item.file, item.title, item.rule, item.category].some(value => value.toLocaleLowerCase().includes(query))
}))

async function showResult() {
  resultView.value = 'summary'
  detailSection.value = 'findings'
  priorityFilter.value = scan.value?.report.priority_counts.focus ? 'focus' : scan.value?.report.priority_counts.review ? 'review' : 'all'
  selectedFile.value = ''
  detailQuery.value = ''
  await nextTick()
  document.getElementById('scan-result')?.scrollIntoView({ behavior: 'smooth', block: 'start' })
}
function openDetailed(priority: 'all' | Priority = 'all', file = '') {
  resultView.value = 'details'
  detailSection.value = 'findings'
  priorityFilter.value = priority
  selectedFile.value = file
  detailQuery.value = ''
}

async function api(path: string, body?: unknown, consent = false) {
  const headers: Record<string, string> = {}
  const init: RequestInit = {}
  if (body !== undefined) {
    init.method = 'POST'
    headers['Content-Type'] = 'application/json'
    headers['X-AASC-Request'] = '1'
    init.body = JSON.stringify(body)
  }
  if (consent) headers['X-AASC-Consent'] = 'local-read-only'
  if (apiToken.value) headers['X-AASC-Token'] = apiToken.value
  init.headers = headers
  const response = await fetch(API.value + path, init)
  const raw = await response.text()
  let data: any
  try { data = JSON.parse(raw) }
  catch { throw new Error(`本地服务返回了非 JSON 响应（HTTP ${response.status}）。请检查后端日志。`) }
  if (!response.ok) throw new Error(typeof data.detail === 'string' ? data.detail : `请求失败 ${response.status}`)
  return data
}
async function refresh() {
  try { history.value = await api('/api/scans'); candidates.value = await api('/api/local/candidates') }
  catch { error.value = '无法连接本地服务。桌面版可关闭后重新打开应用；开发模式请检查 FastAPI 是否已启动。' }
}
async function submitRepo() {
  busy.value = true; error.value = ''; scan.value = null
  try { scan.value = await api('/api/scans/repo', { url: url.value.trim(), commit: commit.value.trim(), external: selected.value, allow_osv_network: osvConsent.value }); await refresh(); await showResult() }
  catch (e) { error.value = String(e instanceof Error ? e.message : e) }
  finally { busy.value = false }
}
async function submitLocal() {
  busy.value = true; error.value = ''; scan.value = null
  try { scan.value = await api('/api/scans/local', { authorized: localConsent.value, include_common: includeCommon.value, custom_paths: customPaths.value.split('\n').map(x => x.trim()).filter(Boolean), external: localSelected.value, allow_osv_network: localOsvConsent.value }, true); await refresh(); await showResult() }
  catch (e) { error.value = String(e instanceof Error ? e.message : e) }
  finally { busy.value = false }
}
async function openScan(id: number) {
  error.value = ''
  try { scan.value = await api(`/api/scans/${id}`); await showResult() }
  catch (e) { error.value = String(e instanceof Error ? e.message : e) }
}
async function downloadReport(format: 'summary' | 'details') {
  if (!scan.value) return
  error.value = ''
  try {
    const path = format === 'summary' ? 'summary.md' : 'details.csv'
    const headers = apiToken.value ? { 'X-AASC-Token': apiToken.value } : undefined
    const response = await fetch(`${API.value}/api/scans/${scan.value.id}/${path}`, { headers })
    if (!response.ok) throw new Error(`下载失败（HTTP ${response.status}）`)
    const blobUrl = URL.createObjectURL(await response.blob())
    const link = document.createElement('a')
    link.href = blobUrl
    link.download = `aasc-${format}-${scan.value.id}.${format === 'summary' ? 'md' : 'csv'}`
    link.click()
    window.setTimeout(() => URL.revokeObjectURL(blobUrl), 1000)
  } catch (e) { error.value = String(e instanceof Error ? e.message : e) }
}
async function initialize() {
  try {
    if (window.__TAURI__) {
      const config = await window.__TAURI__.core.invoke<{ base_url: string; api_token: string }>('backend_config')
      API.value = config.base_url
      apiToken.value = config.api_token
    }
    const deadline = Date.now() + 15_000
    while (Date.now() < deadline) {
      try {
        const health = await api('/api/health')
        if (health.status === 'ok') { await refresh(); return }
      } catch (e) {
        if (String(e).includes('校验失败')) throw e
      }
      await new Promise(resolve => window.setTimeout(resolve, 300))
    }
    throw new Error('本地后端启动超时。请关闭并重新打开应用；若仍失败，请查看应用数据目录中的 backend.log。')
  } catch (e) { error.value = String(e instanceof Error ? e.message : e) }
}
onMounted(initialize)
</script>

<template>
  <main class="shell">
    <header><div><h1>AI Agent Security Center</h1><p>V1.0 · 静态与配置审计 · 本地保存历史</p></div><span class="badge">无运行时监控</span></header>
    <nav><button :class="{active:tab==='repo'}" @click="tab='repo'">GitHub 安装前审核</button><button :class="{active:tab==='local'}" @click="tab='local'">本地资产审核</button><button :class="{active:tab==='history'}" @click="tab='history';refresh()">扫描历史</button></nav>
    <p v-if="error" class="error" role="alert">{{ error }}</p>
    <section v-if="tab==='repo'" class="panel">
      <h2>扫描指定 GitHub commit</h2><p>只接受公开仓库的 HTTPS 地址与完整 40 位 commit SHA。下载到隔离临时目录，不执行安装脚本。</p>
      <label>仓库地址<input v-model="url" placeholder="https://github.com/owner/repo" autocomplete="off"></label>
      <label>Commit SHA<input v-model="commit" placeholder="40 位十六进制 SHA" autocomplete="off"></label>
      <fieldset><legend>可选外部扫描器</legend><label v-for="name in ['Cisco Skill Scanner','Semgrep','Gitleaks','OSV-Scanner']" :key="name" class="check"><input v-model="selected" type="checkbox" :value="name">{{ name }}</label></fieldset>
      <label v-if="selected.includes('OSV-Scanner')" class="check warning"><input v-model="osvConsent" type="checkbox">我同意 OSV-Scanner 联网查询依赖漏洞信息</label>
      <p class="hint">Cisco 仅调用本地静态扫描，不启用 LLM 或云服务。Semgrep 使用本地规则。外部 CLI 的其他联网行为取决于其版本和配置，请仅选用信任的安装版本。</p>
      <button class="primary" :disabled="busy || !url || !commit" @click="submitRepo">{{ busy ? '扫描中…' : '开始扫描' }}</button>
    </section>
    <section v-if="tab==='local'" class="panel">
      <h2>本地只读资产审核</h2><p>选择本次要扫描的范围。默认仅扫描您填写的自定义路径；勾选后才会同时扫描常见 Claude Code、Codex、Cursor Skills/MCP 路径。不会修改原文件。</p>
      <label class="check scope-choice"><input v-model="includeCommon" type="checkbox">同时扫描自动发现的常见路径（{{ candidates.filter(x=>x.exists).length }} 个存在）</label>
      <details><summary>查看常见路径（{{ candidates.filter(x=>x.exists).length }} 个存在）</summary><ul><li v-for="item in candidates" :key="item.path">{{ item.exists ? '✓' : '○' }} {{ item.path }}</li></ul></details>
      <label>自定义目录或文件（每行一项）<textarea v-model="customPaths" rows="4" placeholder="C:\Users\你的用户名\.claude\skills"></textarea></label>
      <fieldset><legend>可选外部扫描器</legend><label v-for="name in ['Cisco Skill Scanner','Semgrep','Gitleaks','OSV-Scanner']" :key="name" class="check"><input v-model="localSelected" type="checkbox" :value="name">{{ name }}</label></fieldset>
      <label v-if="localSelected.includes('OSV-Scanner')" class="check warning"><input v-model="localOsvConsent" type="checkbox">我同意 OSV-Scanner 联网查询依赖漏洞信息</label>
      <p class="hint">选用外部扫描器时，先复制本次已审计的常规文件到临时目录，再交给 CLI；原文件不被修改。</p>
      <label class="check consent"><input v-model="localConsent" type="checkbox">我授权本次对所选路径进行只读扫描</label>
      <button class="primary" :disabled="busy || !localConsent || (!includeCommon && !customPaths.trim())" @click="submitLocal">{{ busy ? '扫描中…' : '开始本地扫描' }}</button>
    </section>
    <section v-if="tab==='history'" class="panel"><h2>最近 100 次扫描</h2><div v-if="!history.length" class="empty">暂无扫描记录</div><button v-for="item in history" :key="item.id" class="history-row" @click="openScan(item.id)"><span>#{{ item.id }} · {{ item.kind==='github'?'GitHub':'本地' }} · {{ item.source }}</span><small>{{ item.created_at }} · 优先复核 {{ item.priority_counts.focus }} · 共 {{ item.findings_count }} 条</small></button></section>
    <section v-if="scan && (tab==='history' || (tab==='repo' && scan.kind==='github') || (tab==='local' && scan.kind==='local'))" id="scan-result" class="panel result">
      <div class="result-top"><div><h2>扫描结果 #{{ scan.id }}</h2><p>{{ scan.source }} <span v-if="scan.version">· {{ scan.version }}</span></p></div><span class="result-total">{{ scan.report.total_findings }} 条规则命中</span></div>
      <div v-if="scan.kind==='local'" class="scanned-scope"><b>本次实际扫描的本地路径</b><ul><li v-for="path in scannedPaths" :key="path">{{ path }}</li></ul></div>
      <div class="report-actions"><button @click="downloadReport('summary')">下载总结报告</button><button @click="downloadReport('details')">下载完整明细 CSV</button></div>
      <div class="report-tabs" role="tablist" aria-label="报告类型"><button :class="{active:resultView==='summary'}" @click="resultView='summary'">总结报告</button><button :class="{active:resultView==='details'}" @click="openDetailed(scan.report.priority_counts.focus?'focus':'all')">详细列表</button></div>

      <div v-if="resultView==='summary'" class="summary-report">
        <div class="source-banner"><strong>本次报告从哪里来？</strong><p>{{ scan.report.source_note }}</p><small>下方四个外部扫描器状态只表示附加检查的覆盖情况；“未运行”不表示本次完全没有扫描。</small></div>
        <div class="summary-lead"><span class="eyebrow">复核建议</span><h3>{{ scan.report.headline }}</h3><p>{{ scan.report.method_note }}</p></div>
        <div class="priority-grid">
          <button class="priority-card focus" @click="openDetailed('focus')"><span>优先复核</span><strong>{{ scan.report.priority_counts.focus }}</strong><small>{{ scan.report.priority_file_counts.focus }} 个文件 · 建议先看</small></button>
          <button class="priority-card review" @click="openDetailed('review')"><span>常规复核</span><strong>{{ scan.report.priority_counts.review }}</strong><small>{{ scan.report.priority_file_counts.review }} 个文件 · 核实上下文</small></button>
          <button class="priority-card context" @click="openDetailed('context')"><span>参考信息</span><strong>{{ scan.report.priority_counts.context }}</strong><small>{{ scan.report.priority_file_counts.context }} 个文件 · 文档/测试等</small></button>
        </div>
        <p v-if="scan.report.unrun_scanners.length" class="coverage-alert">{{ scan.report.coverage_note }}</p>
        <div class="summary-section"><div class="section-heading"><h3>建议先看的文件</h3><span>按复核优先级和线索组合排序</span></div><div v-if="!scan.report.top_files.length" class="empty">本次没有规则命中；请检查下面的扫描器覆盖情况。</div>
          <button v-for="item in scan.report.top_files" :key="item.file" class="focus-row" @click="openDetailed(item.priority,item.file)"><span :class="['priority-badge',item.priority]">{{ item.priority_label }}</span><span class="focus-main"><b>{{ item.file }}</b><small>{{ item.reason }}</small><small>本优先级 {{ item.priority_finding_count }} 条 / 文件共 {{ item.finding_count }} 条 · 第 {{ item.first_line }} 行起 · {{ item.rules.join('、') }}</small></span><span class="focus-link">查看明细 →</span></button>
        </div>
        <div class="summary-section"><h3>线索类别</h3><div class="category-list"><span v-for="category in scan.report.categories" :key="category.name">{{ category.name }} <b>{{ category.count }}</b></span></div></div>
        <div class="summary-section"><h3>扫描器覆盖</h3><p class="coverage-explain">内置规则随每次扫描自动运行；以下四项是可选的外部扫描器。未安装表示本地服务未找到其可执行文件，也可能是未加入 PATH。</p><div class="scanner-list"><div class="builtin-scanner"><b>内置静态规则</b><span class="ok">已运行</span><small>本次产生 {{ scan.report.builtin_findings }} 条线索</small></div><div v-for="s in scan.scanners" :key="s.name"><b>{{ s.name }}</b><span :class="s.status==='已运行'?'ok':'muted'">{{ s.status }}</span><small>{{ s.reason }}</small></div></div></div>
      </div>

      <div v-if="resultView==='details'" class="details-report">
        <div class="subnav"><button :class="{active:detailSection==='findings'}" @click="detailSection='findings'">风险线索 ({{ scan.findings.length }})</button><button :class="{active:detailSection==='assets'}" @click="detailSection='assets'">资产 ({{ scan.assets.length }})</button><button :class="{active:detailSection==='hashes'}" @click="detailSection='hashes'">文件哈希 ({{ scan.files.length }})</button></div>
        <div v-if="detailSection==='findings'">
          <div class="filter-bar"><label>复核优先级<select v-model="priorityFilter"><option value="focus">优先复核 ({{ scan.report.priority_counts.focus }})</option><option value="review">常规复核 ({{ scan.report.priority_counts.review }})</option><option value="context">参考信息 ({{ scan.report.priority_counts.context }})</option><option value="all">全部 ({{ scan.findings.length }})</option></select></label><label>搜索文件、标题或规则<input v-model="detailQuery" placeholder="输入关键词"></label></div>
          <div v-if="selectedFile" class="file-filter">当前文件：{{ selectedFile }} <button @click="selectedFile=''">清除文件筛选</button></div>
          <p class="result-count">显示 {{ filteredFindings.length }} 条线索。规则级别与复核优先级可能不同，请结合“排序依据”判断。</p>
          <div v-if="!filteredFindings.length" class="empty">当前筛选条件下没有线索。</div>
          <article v-for="(f,i) in filteredFindings" :key="`${f.file}:${f.line}:${f.rule}:${i}`" class="finding"><div><span :class="['priority-badge',f.priority]">{{ f.priority_label }}</span><span :class="['severity',f.severity]">{{ f.severity }}</span><b>{{ f.title }}</b><small>{{ f.scanner }} · {{ f.rule }}</small></div><p class="path">{{ f.file }}:{{ f.line }}</p><p class="reason">排序依据：{{ f.priority_reason }}</p><pre>{{ f.evidence }}</pre><p>建议：{{ f.advice }}</p></article>
        </div>
        <div v-if="detailSection==='assets'"><div v-for="(a,i) in scan.assets" :key="i" class="asset"><b>{{ a.type }}</b><span>{{ a.path }}</span><small>{{ a.detail }}</small></div></div>
        <div v-if="detailSection==='hashes'"><div v-for="(f,i) in scan.files" :key="i" class="asset hash"><span>{{ f.path }}</span><code>{{ f.sha256 }}</code></div></div>
      </div>
      <p class="hint">静态检测会有漏报与误报；V1 不提供沙箱、Sysmon、MCP 网关或拦截。</p>
    </section>
  </main>
</template>
