"""Launch the bundled FastAPI backend for the native desktop app."""

from __future__ import annotations

import argparse
import logging
from pathlib import Path

import uvicorn

from security_center.app import app, default_db


def main() -> None:
    parser = argparse.ArgumentParser(description="AI Agent Security Center local API")
    parser.add_argument("--port", type=int, required=True)
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("--port must be in the range 1..65535")

    log_path: Path = default_db().parent / "backend.log"
    logging.basicConfig(
        filename=log_path,
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=args.port,
        log_config=None,
        access_log=False,
    )


if __name__ == "__main__":
    main()
